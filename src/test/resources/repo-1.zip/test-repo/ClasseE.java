class ClasseE {

  public void a(
  	int a1) { 

  	System.out.println("a");
  	System.out.println("a");
  }

}
