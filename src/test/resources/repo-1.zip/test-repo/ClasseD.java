class ClasseD {

  public void a() {
  	System.out.println("a");
  	System.out.println("a");
  }

}
