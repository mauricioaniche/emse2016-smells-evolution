class ClasseA {

  public void a() {
  	System.out.println("a");
  }

}
