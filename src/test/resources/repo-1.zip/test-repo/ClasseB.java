class ClasseB {

  public void m() {

  }
}

